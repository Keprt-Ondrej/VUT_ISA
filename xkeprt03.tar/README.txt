mytftpclient 

autor:
xkeprt03 Ondřej Keprt xkeprt03@stud.fit.vutbr.cz

spusteni pomoci: sudo ./mytftpclient
-R/W -d path_to_file -t timeout -s block_size -a address,port -c netascii/octet -h
pro ukonceni prikazove radky napiste: end

neni implementovana kontrola MTU
neni implementovano rozsireni pro muilticast